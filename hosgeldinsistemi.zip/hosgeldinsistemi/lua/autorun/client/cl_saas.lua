// lua/autorun/server/cl_saas.lua

function ReceiveMessage()
    local name = net.ReadString()
	
    chat.AddText( Color( 235, 8, 35, 255 ), "Sunucumuza Hoşgeldin!, ", name)
end
net.Receive( "saas_join", ReceiveMessage )