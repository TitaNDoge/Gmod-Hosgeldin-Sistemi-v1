// lua/autorun/server/sv_saas.lua

util.AddNetworkString( "saas_join" )

function SendMessage( ply )
    net.Start( "saas_join" )
	    net.WriteString( ply:Name() )
	net.Send( ply )
end

hook.Add( "PlayerInitialSpawn", "SendMessage", SendMessage )